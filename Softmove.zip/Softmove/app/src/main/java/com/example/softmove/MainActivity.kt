package com.example.softmove

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.softmove.Models.Splashscreenitems
import com.github.islamkhsh.CardSliderViewPager
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate

import com.github.mikephil.charting.utils.ColorTemplate.createColors
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        pieChart.setUsePercentValues(true)
        pieChart.description.isEnabled = false

        pieChart.setExtraOffsets(5f, 10f, 5f, 5f)
        pieChart.dragDecelerationFrictionCoef = 0.95f
        pieChart.setDrawHoleEnabled(true)
        //pieChart.holeColor = Color.WHITE
        pieChart.transparentCircleRadius = 61f

        val yValues = ArrayList<PieEntry>()
        yValues.add(PieEntry(34f, "Yoga"))
        yValues.add(PieEntry(23f, "Stretching"))
        yValues.add(PieEntry(14f, "Cycling"))
        yValues.add(PieEntry(35f, "Running"))

        val dataSet = PieDataSet(yValues, "Excercises")
        dataSet.sliceSpace = 3f
        dataSet.selectionShift = 5f
        dataSet.colors = mutableListOf(
            Color.parseColor("#E91E63"),
            Color.parseColor("#03A9F4"),
            Color.parseColor("#9C27B0"),
            Color.parseColor("#00BCD4")
        )

        val data = PieData(dataSet)
        data.setValueTextColor(15)
        data.setValueTextSize(15f)
        data.setValueTextColor(Color.YELLOW)

        pieChart.data = data
        pieChart.rotationAngle = 180f
        pieChart.animateY(1400, Easing.EaseInOutQuad);
        pieChart.centerText="120 mins"

        pieChart.setCenterTextSize(24f)
        pieChart.invalidate()

        pieChart.setTransparentCircleColor(Color.WHITE);
        pieChart.setTransparentCircleAlpha(110);

    }
}


