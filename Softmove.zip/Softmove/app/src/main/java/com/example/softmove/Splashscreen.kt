package com.example.softmove

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.softmove.Models.Splashscreenitems
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_splashscreen.*

class Splashscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splashscreen)
        val slideritems = arrayListOf<Splashscreenitems>()

        val Sliderimgs = resources.obtainTypedArray(R.array.Sliderimages)

        for (i in resources.getStringArray(R.array.Slidertitles).indices) {
            slideritems.add(
                Splashscreenitems(
                    Sliderimgs.getResourceId(i, -1),
                    resources.getStringArray(R.array.Slidertitles)[i],
                    resources.getStringArray(R.array.SliderDesc)[i]
                )
            )
        }

        Sliderimgs.recycle()
        viewPager.adapter = SplashScreenAdapter(slideritems)
    }
}