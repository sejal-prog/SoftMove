package com.example.softmove.Models

data class Splashscreenitems (
    val sliderimg : Int,
    val slidertitle : String,
    val sliderdesc : String
)