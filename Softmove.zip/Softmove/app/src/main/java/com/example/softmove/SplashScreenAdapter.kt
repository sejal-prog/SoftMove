package com.example.softmove

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.softmove.Models.Splashscreenitems
import com.example.softmove.SplashScreenAdapter.*
import com.github.islamkhsh.CardSliderAdapter
import kotlinx.android.synthetic.main.slider_item.view.*

class SplashScreenAdapter(private val splashitems: List<Splashscreenitems>) : CardSliderAdapter<SplashViewHolder>() {


    override fun bindVH(holder: SplashViewHolder, position: Int) {

        val splashscreenitem = splashitems[position]

        holder.itemView.run {
            slider_img.setImageResource(splashscreenitem.sliderimg)
            slider_title.text = splashscreenitem.slidertitle
            slider_desc.text = splashscreenitem.sliderdesc
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SplashViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.slider_item, parent, false)

        return SplashViewHolder(view)
    }

    override fun getItemCount() = splashitems.size


    class SplashViewHolder(view: View) : RecyclerView.ViewHolder(view)
}